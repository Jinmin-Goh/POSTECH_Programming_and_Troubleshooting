#ifndef __MENU_H
#define __MENU_H

void textMenu(char string[], int stringSize);
int patternMenu();
int speedMenu();
int colorMenu();

#endif