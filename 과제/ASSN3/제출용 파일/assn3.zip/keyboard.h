
#ifndef KEYBOARD_H
#define KEYBOARD_H

// return number when keyboard pressed. works same as kbhit of conio.h
int kbhit(); 

#endif