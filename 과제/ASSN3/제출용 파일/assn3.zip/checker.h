#ifndef __CHECKER_H
#define __CHECKER_H

int inputStringLength(char string[]);
int inputStringChecker(char string[], int stringSize);

#endif