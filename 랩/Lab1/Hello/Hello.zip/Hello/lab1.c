/*
* ù ��° C���α׷�
* �ۼ��� : ������
*/

#include<stdio.h>
int main(void)   
{
	printf("EEEEE  RRRRR   IIIII   CCCC   9999\n");
	printf("E      R    R    I    C      9    9\n");
	printf("EEEEE  RRRRR     I    C       99999\n");
	printf("E      R   R     I    C           9\n");
	printf("EEEEE  R    R  IIIII   CCCC   9999\n");
	return 0;
}